"use client";

import { useEffect, useRef, useState, useTransition, useCallback } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { toast } from "sonner";
import { markStationReady } from "@/lib/station-actions";
import { STATIONS, type StationKey } from "@/lib/stations";
import { cn } from "@/lib/utils";

export type StationOrder = {
  id: string;
  tableNumber: string;
  createdAt: string;
  items: { name: string; qty: number }[];
};

function timeAgo(iso: string): string {
  const mins = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 1) return "только что";
  if (mins < 60) return `${mins} мин`;
  return `${Math.floor(mins / 60)} ч`;
}

export function StationBoard({
  station,
  orders,
  name,
  secondaryLink,
}: {
  station: StationKey;
  orders: StationOrder[];
  name: string;
  secondaryLink?: { href: string; label: string };
}) {
  const cfg = STATIONS[station];
  const router = useRouter();
  const [pending, start] = useTransition();
  const [, setTick] = useState(0);
  const [online, setOnline] = useState(true);
  const [soundOn, setSoundOn] = useState(false);

  const audioRef = useRef<AudioContext | null>(null);
  const knownRef = useRef<Set<string> | null>(null);

  const beep = useCallback(() => {
    const ctx = audioRef.current;
    if (!ctx) return;
    const now = ctx.currentTime;
    [784, 1046].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, now + i * 0.18);
      gain.gain.exponentialRampToValueAtTime(0.25, now + i * 0.18 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.18 + 0.16);
      osc.connect(gain).connect(ctx.destination);
      osc.start(now + i * 0.18);
      osc.stop(now + i * 0.18 + 0.18);
    });
  }, []);

  const enableSound = () => {
    try {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      const ctx = audioRef.current ?? new Ctx();
      audioRef.current = ctx;
      ctx.resume();
      setSoundOn(true);
      beep();
      toast.success("Звук включён");
    } catch {
      toast.error("Звук недоступен");
    }
  };

  useEffect(() => {
    const ids = new Set(orders.map((o) => o.id));
    if (knownRef.current === null) {
      knownRef.current = ids;
      return;
    }
    let hasNew = false;
    ids.forEach((id) => {
      if (!knownRef.current!.has(id)) hasNew = true;
    });
    if (hasNew && soundOn) beep();
    knownRef.current = ids;
  }, [orders, soundOn, beep]);

  // Real-time via the shared SSE channel
  useEffect(() => {
    let es: EventSource | null = null;
    try {
      es = new EventSource("/waiter/api/stream");
      es.onmessage = (e) => {
        if (e.data === "update") router.refresh();
      };
    } catch {
      /* SSE unavailable — safety poll keeps it fresh */
    }
    return () => es?.close();
  }, [router]);

  useEffect(() => {
    const id = setInterval(() => {
      setTick((t) => t + 1);
      if (navigator.onLine) router.refresh();
    }, 25000);
    return () => clearInterval(id);
  }, [router]);

  useEffect(() => {
    const up = () => {
      setOnline(true);
      router.refresh();
    };
    const down = () => setOnline(false);
    setOnline(navigator.onLine);
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => {
      window.removeEventListener("online", up);
      window.removeEventListener("offline", down);
    };
  }, [router]);

  const ready = (id: string) =>
    start(async () => {
      try {
        await markStationReady(id, station);
        toast.success(cfg.readyToast);
      } catch {
        toast.error("Не удалось отметить");
      }
    });

  const logout = async () => {
    await fetch("/waiter/api/logout", { method: "POST" });
    router.push(cfg.loginPath);
    router.refresh();
  };

  return (
    <main className="mx-auto min-h-[100svh] max-w-2xl px-4 pb-20 pt-5">
      <header className="mb-4 flex items-center justify-between gap-3">
        <div className="min-w-0">
          <h1 className="truncate font-heading text-2xl">
            {cfg.title} · <span className="text-gold">{name}</span>
          </h1>
          <p className="flex items-center gap-1.5 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
            <span
              className={cn(
                "inline-block size-1.5 rounded-full",
                online ? "animate-pulse bg-emerald-400" : "bg-red-500"
              )}
            />
            {online ? cfg.headerSub : "Нет сети — переподключаемся"}
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {secondaryLink && (
            <Link
              href={secondaryLink.href}
              className="rounded-full border border-border px-3 py-2 text-xs uppercase tracking-wider text-muted-foreground transition-colors hover:border-gold/40 hover:text-gold"
            >
              {secondaryLink.label}
            </Link>
          )}
          {!soundOn && (
            <button
              onClick={enableSound}
              className="rounded-full border border-gold/40 px-3 py-2 text-xs uppercase tracking-wider text-gold transition-colors hover:bg-gold hover:text-primary-foreground"
            >
              🔔 Звук
            </button>
          )}
          <button
            onClick={logout}
            className="rounded-full border border-border px-3 py-2 text-xs uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:border-gold/40 hover:text-gold"
          >
            Выйти
          </button>
        </div>
      </header>

      <div className="mb-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
        {cfg.listLabel} · {orders.length}
      </div>

      {orders.length === 0 ? (
        <div className="rounded-2xl border border-border bg-card/40 px-5 py-12 text-center text-sm text-muted-foreground">
          {cfg.emptyText}
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((o) => (
            <article
              key={o.id}
              className="rounded-2xl border border-border bg-card/50 p-4"
            >
              <div className="flex items-center justify-between">
                <span className="font-heading text-xl">
                  Стол №{o.tableNumber}
                </span>
                <span className="text-[11px] text-muted-foreground">
                  {timeAgo(o.createdAt)}
                </span>
              </div>

              <ul className="mt-2 space-y-0.5 text-sm">
                {o.items.map((it, i) => (
                  <li key={i} className="flex items-center gap-1.5">
                    <span>{cfg.icon}</span>
                    {it.name} <span className="text-gold">×{it.qty}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-3 flex justify-end">
                <button
                  onClick={() => ready(o.id)}
                  disabled={pending}
                  className="rounded-full border border-emerald-500/40 px-4 py-1.5 text-xs uppercase tracking-wider text-emerald-400 transition-colors hover:bg-emerald-500 hover:text-white disabled:opacity-40"
                >
                  {cfg.readyLabel}
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </main>
  );
}
