"use server";

import { revalidatePath } from "next/cache";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { orders, orderItems, waiterCalls } from "@/db/schema";
import { getSession } from "@/lib/session";
import { notifyWaiters } from "@/lib/realtime";
import { tagLineStations } from "@/lib/order-tagging";
import { priceOrder } from "@/lib/order-pricing";
import { getOrCreateTableSession } from "@/lib/table-session";
import { deductForOrder, restockForOrder } from "@/lib/stock-deduct";
import { sendOrderToTelegram } from "@/lib/telegram";

async function requireStaff() {
  const session = await getSession();
  if (!session || (session.role !== "waiter" && session.role !== "manager")) {
    throw new Error("Unauthorized");
  }
  return session;
}

type OrderStatus = "pending" | "cooking" | "delivered" | "cancelled";

/**
 * Advance an order's status. Authorized for waiters and managers only —
 * the client contour can never call this (no valid session).
 */
export async function advanceOrder(id: string, status: OrderStatus) {
  const session = await requireStaff();

  if (status === "cancelled") {
    // Read first so we can reverse stock and guard against double-cancel.
    const [cur] = await db
      .select({ status: orders.status, snap: orders.itemsSnapshot })
      .from(orders)
      .where(eq(orders.id, id));
    await db
      .update(orders)
      .set({ status, updatedAt: sql`now()` })
      .where(eq(orders.id, id));
    if (cur && cur.status !== "cancelled") {
      const restock = (cur.snap ?? [])
        .filter((it) => it.slug)
        .map((it) => ({ id: it.slug as string, qty: it.quantity }));
      await restockForOrder(restock);
    }
  } else {
    await db
      .update(orders)
      .set({
        status,
        updatedAt: sql`now()`,
        // credit the waiter who actually served it
        ...(status === "delivered" ? { servedBy: session.name ?? null } : {}),
      })
      .where(eq(orders.id, id));
  }

  await notifyWaiters();
  revalidatePath("/waiter");
  revalidatePath("/bar");
  revalidatePath("/hookah");
  revalidatePath("/kitchen");
  revalidatePath("/admin");
}

export type ManualLine = {
  id: string; // dish slug
  variantKey?: string;
  nameRu: string;
  nameUz: string;
  nameEn: string;
  variantLabelRu?: string;
  variantLabelUz?: string;
  variantLabelEn?: string;
  price: number;
  qty: number;
};

/**
 * Offline order: a waiter takes a verbal order and submits it himself.
 * Goes through the exact same pipeline as a client order, so lines route
 * to the bartender (drinks), hookah master, and the kitchen (food) on their
 * own boards. The waiter is credited as the one who took it.
 */
export async function createManualOrder(input: {
  tableNumber: string;
  isBirthday?: boolean;
  lines: ManualLine[];
}) {
  const session = await requireStaff();

  const table = (input.tableNumber ?? "").trim();
  if (!table) throw new Error("Укажите стол");
  const lines = (input.lines ?? []).filter((l) => l.qty > 0);
  if (lines.length === 0) throw new Error("Добавьте хотя бы одну позицию");

  // Same server-authoritative pricing as a guest order: validates prices
  // against the DB and applies the 20% service charge + birthday −10%.
  const priced = await priceOrder(
    lines.map((l) => ({ id: l.id, qty: l.qty, price: l.price })),
    input.isBirthday ?? false
  );
  if (!priced.ok) throw new Error(priced.error);
  const { subtotal, service, total } = priced;

  const stationMap = await tagLineStations(lines.map((l) => l.id));
  const sessionId = await getOrCreateTableSession(table);

  const [order] = await db
    .insert(orders)
    .values({
      tableNumber: table,
      status: "pending",
      totalPrice: total,
      serviceCharge: service,
      isBirthday: input.isBirthday ?? false,
      servedBy: session.name ?? null,
      sessionId,
      itemsSnapshot: lines.map((l) => {
        const st = stationMap.get(l.id) ?? "kitchen";
        return {
          slug: l.id,
          nameRu: l.nameRu,
          nameUz: l.nameUz,
          nameEn: l.nameEn,
          variantLabelRu: l.variantLabelRu,
          variantLabelUz: l.variantLabelUz,
          variantLabelEn: l.variantLabelEn,
          quantity: l.qty,
          price: l.price,
          station: st,
          isDrink: st === "bar",
          isHookah: st === "hookah",
        };
      }),
    })
    .returning({ id: orders.id });

  await db.insert(orderItems).values(
    lines.map((l) => ({
      orderId: order.id,
      dishNameRu: l.nameRu,
      dishNameUz: l.nameUz,
      dishNameEn: l.nameEn,
      variantLabelRu: l.variantLabelRu ?? null,
      variantLabelUz: l.variantLabelUz ?? null,
      variantLabelEn: l.variantLabelEn ?? null,
      quantity: l.qty,
      price: l.price,
    }))
  );

  await deductForOrder(lines.map((l) => ({ id: l.id, qty: l.qty })));
  await notifyWaiters();

  try {
    await sendOrderToTelegram(
      order.id,
      table,
      lines.map((l) => ({
        name: l.nameRu,
        variantLabel: l.variantLabelRu,
        qty: l.qty,
        price: l.price,
      })),
      subtotal,
      service,
      total,
      input.isBirthday ?? false
    );
  } catch (err) {
    console.error("Telegram (manual order) failed:", err);
  }

  revalidatePath("/waiter");
  revalidatePath("/bar");
  revalidatePath("/hookah");
  revalidatePath("/kitchen");
  return { id: order.id };
}

/** Mark a waiter call as handled. */
export async function resolveCall(id: string) {
  const session = await requireStaff();
  await db
    .update(waiterCalls)
    .set({
      status: "done",
      resolvedAt: sql`now()`,
      resolvedBy: session.name ?? null,
    })
    .where(eq(waiterCalls.id, id));
  await notifyWaiters();
  revalidatePath("/waiter");
}
