"use server";

import { revalidatePath } from "next/cache";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { getSession } from "@/lib/session";
import { notifyWaiters } from "@/lib/realtime";
import {
  STATIONS,
  STATION_READY_COLUMN,
  type StationKey,
} from "@/lib/stations";

/** Mark an order's items for one station as prepared. Only touches that
 *  station's ready flag — other stations and the waiter are unaffected. */
export async function markStationReady(orderId: string, station: StationKey) {
  const cfg = STATIONS[station];
  const session = await getSession();
  if (!session || (session.role !== cfg.role && session.role !== "manager")) {
    throw new Error("Unauthorized");
  }

  await db
    .update(orders)
    .set({ [STATION_READY_COLUMN[station]]: true, updatedAt: sql`now()` })
    .where(eq(orders.id, orderId));

  await notifyWaiters();
  revalidatePath(cfg.homePath);
  revalidatePath("/waiter");
}
