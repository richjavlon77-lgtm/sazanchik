import "server-only";
import { inArray } from "drizzle-orm";
import { db } from "@/db";
import { dishes, dishVariants } from "@/db/schema";

const SERVICE_RATE = 0.2;
const BIRTHDAY_RATE = 0.1;

type Line = { id: string; qty: number; price: number };
type PricedOk = {
  ok: true;
  subtotal: number;
  discount: number;
  service: number;
  total: number;
};
type PricedErr = { ok: false; error: string };

/**
 * Server-authoritative pricing. Client-sent prices are NEVER trusted: each
 * line price must match a real price for that dish in the DB (base price, or
 * one of its portion-variant prices). Totals are recomputed server-side with
 * the same rules as the cart (20% service, −10% birthday). Out-of-stock or
 * unpublished dishes are rejected. This protects the finance figures.
 */
export async function priceOrder(
  lines: Line[],
  isBirthday: boolean
): Promise<PricedOk | PricedErr> {
  if (!lines.length) return { ok: false, error: "Корзина пуста" };

  const slugs = [...new Set(lines.map((l) => l.id))];
  const dishRows = await db
    .select({
      id: dishes.id,
      slug: dishes.slug,
      price: dishes.price,
      isPublished: dishes.isPublished,
      inStock: dishes.inStock,
    })
    .from(dishes)
    .where(inArray(dishes.slug, slugs));

  const bySlug = new Map(dishRows.map((d) => [d.slug, d]));

  const variantRows = dishRows.length
    ? await db
        .select({ dishId: dishVariants.dishId, price: dishVariants.price })
        .from(dishVariants)
        .where(
          inArray(
            dishVariants.dishId,
            dishRows.map((d) => d.id)
          )
        )
    : [];
  const variantPrices = new Map<string, number[]>();
  for (const v of variantRows) {
    if (!variantPrices.has(v.dishId)) variantPrices.set(v.dishId, []);
    variantPrices.get(v.dishId)!.push(v.price);
  }

  let subtotal = 0;
  for (const l of lines) {
    const d = bySlug.get(l.id);
    if (!d || !d.isPublished) return { ok: false, error: "Позиция недоступна" };
    if (!d.inStock) return { ok: false, error: "Блюдо закончилось" };
    const valid = variantPrices.get(d.id) ?? (d.price != null ? [d.price] : []);
    if (!valid.includes(l.price)) {
      return { ok: false, error: "Цена изменилась — обновите меню" };
    }
    subtotal += l.price * l.qty;
  }

  const discount = isBirthday ? Math.round(subtotal * BIRTHDAY_RATE) : 0;
  const service = Math.round((subtotal - discount) * SERVICE_RATE);
  const total = subtotal - discount + service;
  return { ok: true, subtotal, discount, service, total };
}
